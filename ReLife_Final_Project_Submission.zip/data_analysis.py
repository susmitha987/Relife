#!/usr/bin/env python
# coding: utf-8

# In[4]:


import os

print(os.getcwd())
print(os.listdir())


# In[5]:


import pandas as pd
import matplotlib.pyplot as plt

df1 = pd.read_csv("ReLife_Cleaned_File1 (1).csv")
df2 = pd.read_csv("ReLife_Cleaned_File2.csv")

print("Dataset 1:", df1.shape)
print("Dataset 2:", df2.shape)


# In[6]:


print("DATASET 1 COLUMNS:")
print(df1.columns.tolist())

print("\nDATASET 2 COLUMNS:")
print(df2.columns.tolist())


# In[7]:


return_data = df1[df1["Return_Status"] == "Returned"]

category_returns = return_data["Product_Category"].value_counts()

print(category_returns)


# In[6]:


# Task 4: Return Reason Analysis

returned_data = df1[df1["Return_Status"] == "Returned"]

print("Return Reasons Among Returned Products:")
display(returned_data["Return_Reason"].value_counts())

print("\nReturn Reason Percentages:")
display(
    (returned_data["Return_Reason"].value_counts(normalize=True) * 100)
    .round(2)
)


# In[7]:


# Task 4: Returns by Product Category

category_returns = returned_data["Product_Category"].value_counts()

print("Returned Products by Category:")
display(category_returns)

print("\nPercentage of Returned Products by Category:")
display(
    (category_returns / len(returned_data) * 100).round(2)
)


# In[8]:


# Task 4: Return Cost Analysis by Category

return_cost_by_category = (
    returned_data.groupby("Product_Category")["Return_Cost"]
    .sum()
    .sort_values(ascending=False)
)

print("Total Return Cost by Product Category:")
display(return_cost_by_category)

print("\nAverage Return Cost by Product Category:")
display(
    returned_data.groupby("Product_Category")["Return_Cost"]
    .mean()
    .round(2)
    .sort_values(ascending=False)
)


# In[9]:


# Task 4: Profit/Loss Analysis by Category

profit_loss_by_category = (
    returned_data.groupby("Product_Category")["Profit_Loss"]
    .sum()
    .sort_values(ascending=False)
)

print("Total Profit/Loss by Product Category:")
display(profit_loss_by_category)

print("\nAverage Profit/Loss by Product Category:")
display(
    returned_data.groupby("Product_Category")["Profit_Loss"]
    .mean()
    .round(2)
    .sort_values(ascending=False)
)


# In[10]:


# Task 4: CO2 Emissions Analysis by Category

co2_by_category = (
    returned_data.groupby("Product_Category")["CO2_Emissions"]
    .sum()
    .sort_values(ascending=False)
)

print("Total CO2 Emissions by Product Category:")
display(co2_by_category)

print("\nAverage CO2 Emissions by Product Category:")
display(
    returned_data.groupby("Product_Category")["CO2_Emissions"]
    .mean()
    .round(2)
    .sort_values(ascending=False)
)


# In[2]:


import pandas as pd
import matplotlib.pyplot as plt

df1 = pd.read_csv("ReLife_Cleaned_File1 (1).csv")
df2 = pd.read_csv("ReLife_Cleaned_File2.csv")

returned_data = df1[df1["Return_Status"] == "Returned"]

print("Dataset 1:", df1.shape)
print("Dataset 2:", df2.shape)
print("Returned records:", len(returned_data))


# In[3]:


# Task 4: Return Reasons by Product Category

reason_category_table = pd.crosstab(
    returned_data["Product_Category"],
    returned_data["Return_Reason"]
)

print("Return Reasons by Product Category:")
display(reason_category_table)


# In[4]:


# Task 4: Order Quantity and Return Cost Analysis

print("Average Return Cost by Order Quantity:")

quantity_cost_analysis = (
    returned_data.groupby("Order_Quantity")["Return_Cost"]
    .agg(["count", "mean", "sum"])
    .round(2)
)

display(quantity_cost_analysis)


# In[5]:


# Task 4: CO2 Emissions and Return Cost Correlation

correlation = returned_data[
    ["CO2_Emissions", "Return_Cost"]
].corr()

print("Correlation Between CO2 Emissions and Return Cost:")
display(correlation)


# In[6]:


# Task 4: Check Variation in the Columns

print("Unique Return Cost values:")
display(returned_data["Return_Cost"].unique())

print("\nStandard deviation:")
display(
    returned_data[["CO2_Emissions", "Return_Cost"]]
    .std()
)


# In[7]:


# Task 4: CO2 Emissions vs Product Price

print("CO2 Emissions by Product Price:")

display(
    returned_data.groupby("Product_Price")["CO2_Emissions"]
    .agg(["count", "mean", "sum"])
    .round(2)
)


# In[8]:


# Task 4: Correlation Between Product Price and CO2 Emissions

correlation = returned_data[
    ["Product_Price", "CO2_Emissions"]
].corr()

print("Correlation Between Product Price and CO2 Emissions:")
display(correlation.round(3))


# In[9]:


# Task 4: Days to Return Analysis

print("Overall Days to Return:")

display(
    returned_data["Days_to_Return"]
    .describe()
    .round(2)
)

print("\nAverage Days to Return by Return Reason:")

display(
    returned_data.groupby("Return_Reason")["Days_to_Return"]
    .agg(["count", "mean", "median", "min", "max"])
    .round(2)
    .sort_values("mean", ascending=False)
)


# In[10]:


# Task 4: Packaging Waste Analysis

print("Overall Packaging Waste for Returned Products:")

display(
    returned_data["Packaging_Waste"]
    .describe()
    .round(2)
)

print("\nPackaging Waste by Product Category:")

display(
    returned_data.groupby("Product_Category")["Packaging_Waste"]
    .agg(["count", "mean", "sum"])
    .round(2)
    .sort_values("sum", ascending=False)
)


# In[11]:


# Task 4: Data Quality Validation

print("Missing Values in Dataset 1:")
display(df1.isnull().sum().sort_values(ascending=False))

print("\nDuplicate Rows in Dataset 1:")
print(df1.duplicated().sum())

print("\nMissing Values in Dataset 2:")
display(df2.isnull().sum().sort_values(ascending=False))

print("\nDuplicate Rows in Dataset 2:")
print(df2.duplicated().sum())


# In[12]:


# Task 4: Final Data Quality Summary

print("DATASET 1")
print("Shape:", df1.shape)
print("Total missing values:", df1.isnull().sum().sum())
print("Duplicate rows:", df1.duplicated().sum())

print("\nDATASET 2")
print("Shape:", df2.shape)
print("Total missing values:", df2.isnull().sum().sum())
print("Duplicate rows:", df2.duplicated().sum())


# In[13]:


# Task 4: Dataset 2 - Sales and Refund Summary

print("DATASET 2: SALES AND REFUND ANALYSIS")

print("\nTotal Records:", len(df2))
print("Total Revenue:", round(df2["Total Revenue"].sum(), 2))
print("Final Revenue:", round(df2["Final Revenue"].sum(), 2))
print("Overall Revenue:", round(df2["Overall Revenue"].sum(), 2))

print("Total Refund Amount:", round(df2["Refunds"].abs().sum(), 2))
print("Total Purchased Items:", df2["Purchased Item Count"].sum())
print("Total Refunded Items:", df2["Refunded Item Count"].abs().sum())

print("\nAverage Final Revenue per Record:")
print(round(df2["Final Revenue"].mean(), 2))


# In[14]:


# Task 4: Revenue Analysis by Category

category_revenue = (
    df2.groupby("Category")
    .agg(
        Total_Revenue=("Total Revenue", "sum"),
        Final_Revenue=("Final Revenue", "sum"),
        Overall_Revenue=("Overall Revenue", "sum"),
        Refund_Amount=("Refunds", lambda x: x.abs().sum())
    )
    .round(2)
    .sort_values("Total_Revenue", ascending=False)
)

print("Revenue and Refund Analysis by Category:")
display(category_revenue)


# In[15]:


# Task 4: Purchased and Refunded Items by Category

item_analysis = (
    df2.groupby("Category")
    .agg(
        Purchased_Items=("Purchased Item Count", "sum"),
        Refunded_Items=("Refunded Item Count", lambda x: x.abs().sum())
    )
)

item_analysis["Refund_Rate_Percent"] = (
    item_analysis["Refunded_Items"]
    / item_analysis["Purchased_Items"].replace(0, float("nan"))
    * 100
)

item_analysis = item_analysis.round(2).sort_values(
    "Refund_Rate_Percent", ascending=False
)

print("Purchased Items, Refunded Items, and Refund Rate by Category:")
display(item_analysis)


# In[16]:


# Task 4: Complete Refund Rate Summary

print("Number of categories:", df2["Category"].nunique())

print("\nCategories with zero purchases:")
display(
    item_analysis[item_analysis["Purchased_Items"] == 0]
)

print("\nAll categories sorted by refund rate:")
display(
    item_analysis.sort_values(
        "Refund_Rate_Percent",
        ascending=False,
        na_position="last"
    )
)


# In[17]:


# Task 4: Monthly Revenue Analysis

df2["Date"] = pd.to_datetime(df2["Date"], errors="coerce")

monthly_revenue = (
    df2.groupby(df2["Date"].dt.to_period("M"))
    .agg(
        Total_Revenue=("Total Revenue", "sum"),
        Final_Revenue=("Final Revenue", "sum"),
        Refund_Amount=("Refunds", lambda x: x.abs().sum())
    )
    .round(2)
)

monthly_revenue.index = monthly_revenue.index.astype(str)

print("Monthly Revenue and Refund Summary:")
display(monthly_revenue)

print("\nMonth with Highest Final Revenue:")
print(monthly_revenue["Final_Revenue"].idxmax())

print("\nMonth with Lowest Final Revenue:")
print(monthly_revenue["Final_Revenue"].idxmin())


# In[18]:


# Task 4: Check Unusual Revenue Records

unusual_revenue = df2[
    (df2["Total Revenue"] <= 0) |
    (df2["Final Revenue"] < 0)
]

print("Number of unusual revenue records:", len(unusual_revenue))

display(
    unusual_revenue[
        [
            "Category",
            "Item Name",
            "Total Revenue",
            "Final Revenue",
            "Refunds"
        ]
    ].head(20)
)


# In[19]:


# Task 4: Classify Unusual Revenue Records

zero_total_revenue = df2["Total Revenue"] == 0
negative_final_revenue = df2["Final Revenue"] < 0

print("Records with zero Total Revenue:",
      zero_total_revenue.sum())

print("Records with negative Final Revenue:",
      negative_final_revenue.sum())

print("Records meeting both conditions:",
      (zero_total_revenue & negative_final_revenue).sum())

print("\nExamples with negative Final Revenue:")
display(
    df2.loc[
        negative_final_revenue,
        ["Category", "Item Name", "Total Revenue",
         "Final Revenue", "Refunds"]
    ].head(10)
)


# In[20]:


# Check whether unusual revenue records have refunds
print("Zero revenue records with no refunds:",
      ((df2["Total Revenue"] == 0) &
       (df2["Refunds"] == 0)).sum())

print("Negative final revenue records with no refunds:",
      ((df2["Final Revenue"] < 0) &
       (df2["Refunds"] == 0)).sum())


# ## Task 4: Data Analysis — Key Findings and Conclusion
# 
# ### Key Findings
# 
# **Dataset 1: Returns and Sustainability**
# - The dataset contains 5,000 records, with no missing values or duplicate rows.
# - A total of 1,450 products were returned, giving a return rate of 29%.
# - Clothing had the highest number of returned products, with 661 returns.
# - Defective products were the most common return reason, with 382 returns.
# - Total recorded return costs were 290,000, and total recorded CO₂ emissions were 2,167.5 units as represented in the dataset.
# 
# **Dataset 2: Product Sales and Returns**
# - The dataset contains 70,051 records, with no missing values or duplicate rows.
# - Total Revenue was 4,327,474.33, while Final Revenue was 3,262,988.18.
# - The recorded refund amount was 717,756.33 when displayed as a positive amount.
# - November 2018 had the highest monthly Final Revenue, while February 2019 had the lowest.
# - A total of 10,710 records had negative Final Revenue, and all of these records had nonzero refunds. Five records had zero Total Revenue and no refunds, requiring further inspection.
# 
# ### Conclusion
# 
# The analysis helped identify product categories with more returns, common return reasons, revenue and refund patterns, and unusual financial records. These findings can help a business investigate return causes, review product performance, and improve its return-handling process. The sustainability measures in Dataset 1 may also help explore opportunities to reduce waste and emissions. Since Dataset 1 is simulated and the meaning and units of some financial and environmental fields depend on their definitions, the results should be interpreted within the limits of the datasets.
