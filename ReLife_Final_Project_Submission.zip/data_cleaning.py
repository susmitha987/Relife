# Import required libraries
import pandas as pd
import numpy as np

# Check uploaded files
import os

print("Uploaded files:")
print(os.listdir('/content'))

# Load both original datasets

returns_df = pd.read_csv('/content/returns_sustainability_dataset.csv')
sales_df = pd.read_csv('/content/order_dataset.csv')

# Display dataset dimensions
print("RETURNS AND SUSTAINABILITY DATASET")
print("Shape:", returns_df.shape)

print("\nPRODUCT SALES AND RETURNS DATASET")
print("Shape:", sales_df.shape)

# Display first five records
print("\nFirst 5 records of Returns Dataset:")
display(returns_df.head())

print("\nFirst 5 records of Sales Dataset:")
display(sales_df.head())

# Check missing values in both datasets

print("RETURNS AND SUSTAINABILITY DATASET")
print(returns_df.isnull().sum())

print("\nPRODUCT SALES AND RETURNS DATASET")
print(sales_df.isnull().sum())

# Check duplicate records

print("Returns Dataset Duplicates:")
print(returns_df.duplicated().sum())

print("\nSales Dataset Duplicates:")
print(sales_df.duplicated().sum())

# Remove duplicate records

returns_df = returns_df.drop_duplicates()

sales_df = sales_df.drop_duplicates()

# Verify duplicates after removal

print("Returns Dataset Duplicates:", returns_df.duplicated().sum())

print("Sales Dataset Duplicates:", sales_df.duplicated().sum())

print("\nUpdated Dataset Shapes:")
print("Returns Dataset:", returns_df.shape)
print("Sales Dataset:", sales_df.shape)

# Clean column names in both datasets

returns_df.columns = (
    returns_df.columns
    .str.strip()
    .str.lower()
    .str.replace(" ", "_")
)

sales_df.columns = (
    sales_df.columns
    .str.strip()
    .str.lower()
    .str.replace(" ", "_")
)

# Display updated column names

print("Returns Dataset Columns:")
print(returns_df.columns.tolist())

print("\nSales Dataset Columns:")
print(sales_df.columns.tolist())

# Identify text columns in both datasets

returns_text_columns = returns_df.select_dtypes(include="object").columns
sales_text_columns = sales_df.select_dtypes(include="object").columns

# Remove leading and trailing spaces

for column in returns_text_columns:
    returns_df[column] = returns_df[column].str.strip()

for column in sales_text_columns:
    sales_df[column] = sales_df[column].str.strip()

print("Text cleaning completed successfully!")

print("\nReturns Dataset - Text Columns:")
print(returns_text_columns.tolist())

print("\nSales Dataset - Text Columns:")
print(sales_text_columns.tolist())

# Convert Returns dataset date column

returns_df['order_date'] = pd.to_datetime(
    returns_df['order_date'],
    errors='coerce'
)

# Convert Sales dataset date column
sales_df['date'] = pd.to_datetime(
    sales_df['date'],
    dayfirst=True,
    errors='coerce'
)

# Display updated data types

print("Returns Dataset Date Type:")
print(returns_df['order_date'].dtype)

print("\nSales Dataset Date Type:")
print(sales_df['date'].dtype)

# Check invalid dates

print("\nInvalid dates in Returns Dataset:")
print(returns_df['order_date'].isnull().sum())

print("\nInvalid dates in Sales Dataset:")
print(sales_df['date'].isnull().sum())

# Numerical columns in Returns dataset

returns_numeric_columns = [
    'product_price',
    'order_quantity',
    'discount_applied',
    'user_age',
    'days_to_return',
    'order_value',
    'return_cost',
    'profit_loss',
    'co2_emissions',
    'packaging_waste',
    'co2_saved',
    'waste_avoided'
]

# Numerical columns in Sales dataset

sales_numeric_columns = [
    'final_quantity',
    'total_revenue',
    'price_reductions',
    'refunds',
    'final_revenue',
    'sales_tax',
    'overall_revenue',
    'refunded_item_count',
    'purchased_item_count'
]

# Convert columns to numeric

for column in returns_numeric_columns:
    returns_df[column] = pd.to_numeric(
        returns_df[column], errors='coerce'
    )

for column in sales_numeric_columns:
    sales_df[column] = pd.to_numeric(
        sales_df[column], errors='coerce'
    )

print("Numerical data type conversion completed!")

print("\nReturns Dataset Data Types:")
print(returns_df[returns_numeric_columns].dtypes)

print("\nSales Dataset Data Types:")
print(sales_df[sales_numeric_columns].dtypes)

# DATA QUALITY VALIDATION

print("========== RETURNS DATASET ==========")

print("Negative Product Prices:")
print((returns_df['product_price'] < 0).sum())

print("\nNegative Order Quantities:")
print((returns_df['order_quantity'] < 0).sum())

print("\nNegative User Ages:")
print((returns_df['user_age'] < 0).sum())

print("\nNegative Return Costs:")
print((returns_df['return_cost'] < 0).sum())


print("\n========== SALES DATASET ==========")

print("Negative Final Quantities:")
print((sales_df['final_quantity'] < 0).sum())

print("\nNegative Final Revenue:")
print((sales_df['final_revenue'] < 0).sum())

print("\nNegative Total Revenue:")
print((sales_df['total_revenue'] < 0).sum())

print("\nNegative Refunds:")
print((sales_df['refunds'] < 0).sum())

# Inspect negative quantity transactions

negative_transactions = sales_df[
    sales_df['final_quantity'] < 0
]

print("Negative Quantity Transactions:")
display(negative_transactions.head(10))

print("\nNegative Quantity Transaction Count:")
print(len(negative_transactions))

print("\nNegative Quantity Summary:")
print(negative_transactions[
    ['final_quantity', 'total_revenue', 'refunds',
     'final_revenue', 'refunded_item_count',
     'purchased_item_count']
].describe())

# Analyze negative quantity transactions

negative_transactions = sales_df[
    sales_df['final_quantity'] < 0
]

print("Total Negative Quantity Transactions:",
      len(negative_transactions))

print("\nRefunded Item Count:")
print(negative_transactions['refunded_item_count'].value_counts())

print("\nPurchased Item Count:")
print(negative_transactions['purchased_item_count'].value_counts())

print("\nNegative Revenue Transactions:",
      (negative_transactions['final_revenue'] < 0).sum())

print("\nTotal Refund Amount:",
      negative_transactions['refunds'].sum())

# Check return status distribution

print("Return Status Distribution:")
print(returns_df['return_status'].value_counts())

print("\nReturn Reason Distribution:")
print(returns_df['return_reason'].value_counts())

# Check return costs for non-returned orders

print("\nNon-returned orders with return cost:")
print(
    returns_df[
        (returns_df['return_status'] == 'Not Returned') &
        (returns_df['return_cost'] > 0)
    ].shape[0]
)

# Check returned orders with zero return cost

print("\nReturned orders with zero return cost:")
print(
    returns_df[
        (returns_df['return_status'] == 'Returned') &
        (returns_df['return_cost'] == 0)
    ].shape[0]
)

# Validate sustainability measurements

sustainability_columns = [
    'co2_emissions',
    'packaging_waste',
    'co2_saved',
    'waste_avoided'
]

print("SUSTAINABILITY DATA VALIDATION")

for column in sustainability_columns:
    print(
        column,
        "- Negative values:",
        (returns_df[column] < 0).sum()
    )

print("\nSustainability Summary:")
display(returns_df[sustainability_columns].describe())

# FINAL DATA QUALITY REPORT

print("RETURNS & SUSTAINABILITY DATASET")
print("Final Shape:", returns_df.shape)
print("Missing Values:", returns_df.isnull().sum().sum())
print("Duplicate Rows:", returns_df.duplicated().sum())

print("\nPRODUCT SALES & RETURNS DATASET")
print("Final Shape:", sales_df.shape)
print("Missing Values:", sales_df.isnull().sum().sum())
print("Duplicate Rows:", sales_df.duplicated().sum())

# EXPORT CLEANED DATASETS

returns_df.to_csv(
    '/content/ReLife_Cleaned_File1.csv',
    index=False
)

sales_df.to_csv(
    '/content/ReLife_Cleaned_File2.csv',
    index=False
)

print("Both cleaned datasets exported successfully!")

print("File 1: ReLife_Cleaned_File1.csv")
print("File 2: ReLife_Cleaned_File2.csv")

import os

files = [
    '/content/ReLife_Cleaned_File1.csv',
    '/content/ReLife_Cleaned_File2.csv'
]

for file in files:
    if os.path.exists(file):
        print(os.path.basename(file), "- Available")
        print("File size:", round(os.path.getsize(file) / 1024, 2), "KB")
    else:
        print(os.path.basename(file), "- Not Found")

from google.colab import files

files.download('/content/ReLife_Cleaned_File1.csv')
files.download('/content/ReLife_Cleaned_File2.csv')


