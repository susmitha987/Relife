#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import matplotlib.pyplot as plt

df1 = pd.read_csv("ReLife_Cleaned_File1 (1).csv")
df2 = pd.read_csv("ReLife_Cleaned_File2.csv")

print("Dataset 1:", df1.shape)
print("Dataset 2:", df2.shape)


# In[2]:


return_data = df1[df1["Return_Status"] == "Returned"]

category_returns = return_data["Product_Category"].value_counts()

print(category_returns)


# In[3]:


plt.figure(figsize=(8, 5))

category_returns.plot(kind="bar")

plt.title("Returned Products by Category")
plt.xlabel("Product Category")
plt.ylabel("Number of Returned Products")
plt.xticks(rotation=0)
plt.tight_layout()

plt.show()


# In[4]:


# Count returned and non-returned products

return_status = df1["Return_Status"].value_counts()

print(return_status)

# Create a bar chart
plt.figure(figsize=(7, 5))
return_status.plot(kind="bar")

plt.title("Returned vs Non-Returned Products")
plt.xlabel("Return Status")
plt.ylabel("Number of Products")
plt.xticks(rotation=0)
plt.tight_layout()

plt.show()


# In[5]:


# Count the reasons for product returns

return_reasons = df1[df1["Return_Status"] == "Returned"]["Return_Reason"].value_counts()

print(return_reasons)

# Create a bar chart
plt.figure(figsize=(8, 5))
return_reasons.plot(kind="bar")

plt.title("Reasons for Product Returns")
plt.xlabel("Return Reason")
plt.ylabel("Number of Returns")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[6]:


# Calculate the return rate for each product category

category_total = df1["Product_Category"].value_counts()

category_returned = df1[df1["Return_Status"] == "Returned"]["Product_Category"].value_counts()

return_rate = (category_returned / category_total * 100).sort_values(ascending=False)

print(return_rate.round(2))

# Create a bar chart
plt.figure(figsize=(8, 5))
return_rate.plot(kind="bar")

plt.title("Return Rate by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Return Rate (%)")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[7]:


# Compare returned and non-returned products by category

status_by_category = pd.crosstab(
    df1["Product_Category"],
    df1["Return_Status"]
)

print(status_by_category)

# Create a stacked bar chart
status_by_category.plot(
    kind="bar",
    stacked=True,
    figsize=(9, 5)
)

plt.title("Return Status by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Number of Products")
plt.xticks(rotation=45, ha="right")
plt.legend(title="Return Status")
plt.tight_layout()

plt.show()


# In[8]:


# Analyze monthly product returns

df1["Order_Date"] = pd.to_datetime(df1["Order_Date"])

returned_products = df1[df1["Return_Status"] == "Returned"].copy()

returned_products["Month"] = (
    returned_products["Order_Date"].dt.to_period("M").astype(str)
)

monthly_returns = returned_products["Month"].value_counts().sort_index()

print(monthly_returns)

# Create a line chart
plt.figure(figsize=(10, 5))
monthly_returns.plot(kind="line", marker="o")

plt.title("Monthly Product Return Trends")
plt.xlabel("Month")
plt.ylabel("Number of Returns")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[10]:


print(df1.columns.tolist())


# In[11]:


# Find the 10 most frequently returned products

top_returned_products = (
    df1[df1["Return_Status"] == "Returned"]["Product_ID"]
    .value_counts()
    .head(10)
)

print(top_returned_products)

# Create a bar chart
plt.figure(figsize=(10, 5))
top_returned_products.plot(kind="bar")

plt.title("Top 10 Products by Number of Returns")
plt.xlabel("Product ID")
plt.ylabel("Number of Returns")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[12]:


# Calculate average return cost for each product category

average_return_cost = (
    df1[df1["Return_Status"] == "Returned"]
    .groupby("Product_Category")["Return_Cost"]
    .mean()
    .sort_values(ascending=False)
)

print(average_return_cost.round(2))

# Create a bar chart
plt.figure(figsize=(8, 5))
average_return_cost.plot(kind="bar")

plt.title("Average Return Cost by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Average Return Cost")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[13]:


# Calculate average days taken to return products

average_days = (
    df1[df1["Return_Status"] == "Returned"]
    .groupby("Product_Category")["Days_to_Return"]
    .mean()
    .sort_values(ascending=False)
)

print(average_days.round(2))

# Create a bar chart
plt.figure(figsize=(8, 5))
average_days.plot(kind="bar")

plt.title("Average Days to Return by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Average Days to Return")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[14]:


# Calculate average profit or loss by product category

average_profit_loss = (
    df1.groupby("Product_Category")["Profit_Loss"]
    .mean()
    .sort_values(ascending=False)
)

print(average_profit_loss.round(2))

# Create a bar chart
plt.figure(figsize=(8, 5))
average_profit_loss.plot(kind="bar")

plt.title("Average Profit/Loss by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Average Profit/Loss")
plt.axhline(y=0, linewidth=1)
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[15]:


# Calculate total CO2 emissions by product category

co2_by_category = (
    df1.groupby("Product_Category")["CO2_Emissions"]
    .sum()
    .sort_values(ascending=False)
)

print(co2_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(8, 5))
co2_by_category.plot(kind="bar")

plt.title("Total CO2 Emissions by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total CO2 Emissions")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[16]:


# Calculate total CO2 saved by product category

co2_saved_by_category = (
    df1.groupby("Product_Category")["CO2_Saved"]
    .sum()
    .sort_values(ascending=False)
)

print(co2_saved_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(8, 5))
co2_saved_by_category.plot(kind="bar")

plt.title("Total CO2 Saved by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total CO2 Saved")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[17]:


# Calculate total packaging waste by product category

waste_by_category = (
    df1.groupby("Product_Category")["Packaging_Waste"]
    .sum()
    .sort_values(ascending=False)
)

print(waste_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(8, 5))
waste_by_category.plot(kind="bar")

plt.title("Total Packaging Waste by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total Packaging Waste")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[18]:


# Calculate total waste avoided by product category

waste_avoided_by_category = (
    df1.groupby("Product_Category")["Waste_Avoided"]
    .sum()
    .sort_values(ascending=False)
)

print(waste_avoided_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(8, 5))
waste_avoided_by_category.plot(kind="bar")

plt.title("Total Waste Avoided by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total Waste Avoided")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[19]:


# Calculate total revenue by product category

revenue_by_category = (
    df2.groupby("Category")["Total Revenue"]
    .sum()
    .sort_values(ascending=False)
)

print(revenue_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(9, 5))
revenue_by_category.plot(kind="bar")

plt.title("Total Revenue by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total Revenue")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[20]:


# Calculate final revenue by product category

final_revenue_by_category = (
    df2.groupby("Category")["Final Revenue"]
    .sum()
    .sort_values(ascending=False)
)

print(final_revenue_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(9, 5))
final_revenue_by_category.plot(kind="bar")

plt.title("Final Revenue by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Final Revenue")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[21]:


# Calculate total refunds by product category

refunds_by_category = (
    df2.groupby("Category")["Refunds"]
    .sum()
    .sort_values(ascending=False)
)

print(refunds_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(9, 5))
refunds_by_category.plot(kind="bar")

plt.title("Total Refunds by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total Refunds")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[22]:


# Calculate total quantity sold by product category

quantity_by_category = (
    df2.groupby("Category")["Final Quantity"]
    .sum()
    .sort_values(ascending=False)
)

print(quantity_by_category)

# Create a bar chart
plt.figure(figsize=(9, 5))
quantity_by_category.plot(kind="bar")

plt.title("Total Sales Quantity by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total Quantity Sold")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[23]:


# Calculate total price reductions by product category

reductions_by_category = (
    df2.groupby("Category")["Price Reductions"]
    .sum()
    .sort_values(ascending=False)
)

print(reductions_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(9, 5))
reductions_by_category.plot(kind="bar")

plt.title("Total Price Reductions by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total Price Reductions")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[24]:


# Calculate average revenue by product category

average_revenue = (
    df2.groupby("Category")["Total Revenue"]
    .mean()
    .sort_values(ascending=False)
)

print(average_revenue.round(2))

# Create a bar chart
plt.figure(figsize=(9, 5))
average_revenue.plot(kind="bar")

plt.title("Average Revenue by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Average Revenue")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[25]:


# Calculate monthly refund amounts

df2["Date"] = pd.to_datetime(df2["Date"])

monthly_refunds = (
    df2.groupby(df2["Date"].dt.to_period("M"))["Refunds"]
    .sum()
)

print(monthly_refunds.round(2))

# Create a line chart
plt.figure(figsize=(10, 5))
monthly_refunds.plot(kind="line", marker="o")

plt.title("Monthly Refund Trends")
plt.xlabel("Month")
plt.ylabel("Total Refund Amount")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[26]:


# Compare purchased and refunded item counts

item_counts = pd.Series({
    "Purchased Items": df2["Purchased Item Count"].sum(),
    "Refunded Items": df2["Refunded Item Count"].sum()
})

print(item_counts)

# Create a bar chart
plt.figure(figsize=(7, 5))
item_counts.plot(kind="bar")

plt.title("Purchased Items vs Refunded Items")
plt.xlabel("Item Type")
plt.ylabel("Total Item Count")
plt.xticks(rotation=0)
plt.tight_layout()

plt.show()


# In[27]:


# Calculate overall revenue by product category

overall_revenue_by_category = (
    df2.groupby("Category")["Overall Revenue"]
    .sum()
    .sort_values(ascending=False)
)

print(overall_revenue_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(9, 5))
overall_revenue_by_category.plot(kind="bar")

plt.title("Overall Revenue by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Overall Revenue")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[28]:


# Calculate total sales tax by product category

tax_by_category = (
    df2.groupby("Category")["Sales Tax"]
    .sum()
    .sort_values(ascending=False)
)

print(tax_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(9, 5))
tax_by_category.plot(kind="bar")

plt.title("Total Sales Tax by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total Sales Tax")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[30]:


print(df2.columns.tolist())


# In[31]:


# Calculate average total revenue by product category

average_revenue_by_category = (
    df2.groupby("Category")["Total Revenue"]
    .mean()
    .sort_values(ascending=False)
)

print(average_revenue_by_category.round(2))

# Create a bar chart
plt.figure(figsize=(9, 5))
average_revenue_by_category.plot(kind="bar")

plt.title("Average Total Revenue by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Average Total Revenue")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[32]:


# Find the top 10 products by total revenue

top_products_revenue = (
    df2.groupby("Item Name")["Total Revenue"]
    .sum()
    .sort_values(ascending=False)
    .head(10)
)

print(top_products_revenue.round(2))

# Create a bar chart
plt.figure(figsize=(10, 5))
top_products_revenue.plot(kind="bar")

plt.title("Top 10 Products by Total Revenue")
plt.xlabel("Product Name")
plt.ylabel("Total Revenue")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[33]:


# Calculate monthly revenue

df2["Date"] = pd.to_datetime(df2["Date"])

monthly_revenue = (
    df2.groupby(df2["Date"].dt.to_period("M"))["Total Revenue"]
    .sum()
)

print(monthly_revenue.round(2))

# Create a line chart
plt.figure(figsize=(10, 5))
monthly_revenue.plot(kind="line", marker="o")

plt.title("Monthly Revenue Trend")
plt.xlabel("Month")
plt.ylabel("Total Revenue")
plt.grid(True, alpha=0.3)
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[34]:


# Calculate revenue share by category

revenue_share = df2.groupby("Category")["Total Revenue"].sum()

print((revenue_share / revenue_share.sum() * 100).round(2))

# Create a pie chart
plt.figure(figsize=(8, 8))

plt.pie(
    revenue_share,
    labels=revenue_share.index,
    autopct="%1.1f%%",
    startangle=90
)

plt.title("Revenue Share by Product Category")
plt.axis("equal")
plt.tight_layout()

plt.show()


# In[35]:


# Visualize the distribution of total revenue

plt.figure(figsize=(9, 5))

plt.hist(df2["Total Revenue"].dropna(), bins=30, edgecolor="black")

plt.title("Distribution of Total Revenue")
plt.xlabel("Total Revenue")
plt.ylabel("Number of Records")
plt.tight_layout()

plt.show()


# In[36]:


# Explore the relationship between price reductions and total revenue

plt.figure(figsize=(9, 5))

plt.scatter(
    df2["Price Reductions"],
    df2["Total Revenue"],
    alpha=0.4
)

plt.title("Price Reductions vs Total Revenue")
plt.xlabel("Price Reductions")
plt.ylabel("Total Revenue")
plt.tight_layout()

plt.show()


# In[37]:


# Explore the relationship between refunds and final revenue

plt.figure(figsize=(9, 5))

plt.scatter(
    df2["Refunds"],
    df2["Final Revenue"],
    alpha=0.4
)

plt.title("Refunds vs Final Revenue")
plt.xlabel("Refund Amount")
plt.ylabel("Final Revenue")
plt.tight_layout()

plt.show()


# In[38]:


# Compare revenue distributions across product categories

categories = df2["Category"].dropna().unique()

revenue_data = [
    df2.loc[df2["Category"] == category, "Total Revenue"].dropna()
    for category in categories
]

plt.figure(figsize=(10, 5))

plt.boxplot(revenue_data, tick_labels=categories)

plt.title("Revenue Distribution by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Total Revenue")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[39]:


# Calculate monthly sales quantity

monthly_quantity = (
    df2.groupby(df2["Date"].dt.to_period("M"))["Final Quantity"]
    .sum()
    .sort_index()
)

print(monthly_quantity)

# Create a line chart
plt.figure(figsize=(10, 5))

monthly_quantity.plot(kind="line", marker="o")

plt.title("Monthly Sales Quantity Trend")
plt.xlabel("Month")
plt.ylabel("Total Sales Quantity")
plt.grid(True, alpha=0.3)
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

plt.show()


# In[40]:


# Compare total revenue and refunds by category

category_comparison = df2.groupby("Category")[
    ["Total Revenue", "Refunds"]
].sum()

print(category_comparison.round(2))

# Create a grouped bar chart
category_comparison.plot(
    kind="bar",
    figsize=(10, 5)
)

plt.title("Revenue vs Refunds by Product Category")
plt.xlabel("Product Category")
plt.ylabel("Amount")
plt.xticks(rotation=45, ha="right")
plt.legend(title="Metric")
plt.tight_layout()

plt.show()


# In[41]:


# Calculate sustainability impact by product category

sustainability = df1.groupby("Product_Category")[
    ["CO2_Saved", "Waste_Avoided"]
].sum()

print(sustainability.round(2))

# Create two separate charts
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

sustainability["CO2_Saved"].plot(
    kind="bar", ax=axes[0]
)
axes[0].set_title("CO2 Saved by Category")
axes[0].set_xlabel("Product Category")
axes[0].set_ylabel("Total CO2 Saved")
axes[0].tick_params(axis="x", rotation=45)

sustainability["Waste_Avoided"].plot(
    kind="bar", ax=axes[1]
)
axes[1].set_title("Waste Avoided by Category")
axes[1].set_xlabel("Product Category")
axes[1].set_ylabel("Total Waste Avoided")
axes[1].tick_params(axis="x", rotation=45)

plt.tight_layout()
plt.show()

